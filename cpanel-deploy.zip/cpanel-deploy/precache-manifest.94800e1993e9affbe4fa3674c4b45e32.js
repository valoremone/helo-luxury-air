self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "80f0cfcf7f6a8ffb3c4a6ad918c85379",
    "url": "/app/index.html"
  },
  {
    "revision": "6b38aad645199b95aa20",
    "url": "/app/static/css/main.27c3962b.chunk.css"
  },
  {
    "revision": "5cd0f0428ca80840e229",
    "url": "/app/static/js/2.c79020ec.chunk.js"
  },
  {
    "revision": "73e88762c69a3c614405",
    "url": "/app/static/js/3.c02789ba.chunk.js"
  },
  {
    "revision": "6b38aad645199b95aa20",
    "url": "/app/static/js/main.f851d89f.chunk.js"
  },
  {
    "revision": "0fc07577872127c8c4db",
    "url": "/app/static/js/runtime~main.3771d54e.js"
  }
]);